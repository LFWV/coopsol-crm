@echo off
echo Iniciando servidor local para o CRM de Energia...
echo Pressione Ctrl+C para parar o servidor.
python -m http.server 8000
